from django.shortcuts import render, redirect
from .models import *
from .forms import IncidenciaForm
from apps.gestionproyectos.models import *
def homei(request):
     return render(request,'gestionincidencias/listarincidencia.html')

def crearIncidencia(request):
    if request.method == 'POST': 
        form = IncidenciaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listarincidencia')
    else: 
        form =IncidenciaForm()
    return render(request,'gestionincidencias/crearincidencia.html', {'form': form})

def listarIncidencia(request):
    incidencia=Incidencia.objects.all()
    proyecto=Proyecto.objects.all()
    context={'incidencia': incidencia,
    'proyecto': proyecto}
    return render(request, 'gestionincidencias/listarincidencia.html',context)

def editarIncidencia(request,id):
    incidencia=Incidencia.objects.get(id = id)
    if request.method == 'GET':
        form = IncidenciaForm(instance = incidencia)
    else:
        form = IncidenciaForm(request.POST, instance=incidencia)
        if form.is_valid():
            form.save()
        return redirect('listarincidencia')
    return render(request,'gestionincidencias/crearincidencia.html',{'form':form})

def eliminarIncidencia(request,id):
    incidencia=Incidencia.objects.get(id=id)
    if (request.method=='POST'):
        incidencia.delete()
        return redirect('listarincidencia')
    return render(request,'gestionincidencias/eliminarincidencia.html', {'incidencia':incidencia})
        