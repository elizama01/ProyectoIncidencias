from django.shortcuts import render, redirect
from .models import *
from .forms import IncidenciaForm
from apps.gestionproyectos.models import *
from apps.gestionusuarios.models import Usuario
from django.contrib.auth.decorators import login_required

@login_required
def homei(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    return render(request,'gestionincidencias/listarincidencia.html',{'countu':countu,
        'countp':countp,
        'counti':counti,})

@login_required
def crearIncidencia(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    
    if request.method == 'POST': 
        form = IncidenciaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listarincidencia')
    else: 
        form =IncidenciaForm()
    return render(request,'gestionincidencias/crearincidencia.html', {'form': form,'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def listarIncidencia(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    incidencia=Incidencia.objects.all()
    proyecto=Proyecto.objects.all()
    context={'incidencia': incidencia,
    'proyecto': proyecto,'countu':countu,
        'countp':countp,
        'counti':counti,}
    return render(request, 'gestionincidencias/listarincidencia.html',context)

@login_required
def editarIncidencia(request,id):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    incidencia=Incidencia.objects.get(id = id)
    if request.method == 'GET':
        form = IncidenciaForm(instance = incidencia)
    else:
        form = IncidenciaForm(request.POST, instance=incidencia)
        if form.is_valid():
            form.save()
        return redirect('listarincidencia')
    return render(request,'gestionincidencias/crearincidencia.html',{'form':form,'countu':countu,
        'countp':countp,
        'counti':counti,})

@login_required
def eliminarIncidencia(request,id):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    incidencia=Incidencia.objects.get(id=id)
    if (request.method=='POST'):
        incidencia.delete()
        return redirect('listarincidencia')
    return render(request,'gestionincidencias/eliminarincidencia.html', {'incidencia':incidencia,'countu':countu,
        'countp':countp,
        'counti':counti,})

@login_required
def mostrarFlujo(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    return render(request,'gestionincidencias/mostrarflujo.html', {'countu':countu,
        'countp':countp,
        'counti':counti,})