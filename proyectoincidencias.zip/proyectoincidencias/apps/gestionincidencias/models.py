from django.db import models
from django import forms
from apps.gestionusuarios.models import *
from apps.gestionproyectos.models import *
# Create your models here.

class Estado(models.Model):
    id=models.AutoField(primary_key=True)
    nombre_e = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre_e

class Incidencia(models.Model):
    id = models.AutoField(primary_key=True)
    nombre_i = models.CharField(max_length=100)
    proyecto_i=models.ForeignKey(Proyecto,on_delete=models.CASCADE)
    estado_i = models.ForeignKey(Estado,on_delete=models.CASCADE)
    detalles_i = models.TextField()
    responsable_i=models.ForeignKey(Usuario, on_delete=models.CASCADE)
    evidencia_i=models.FileField(blank=True, null=True, upload_to="chapters")
    fecha_i=models.DateField()
   
    def __str__(self):
        return self.nombre_i
    