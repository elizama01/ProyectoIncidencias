from django.contrib import admin
from apps.gestionincidencias.models import *
# Register your models here.
admin.site.register(Incidencia)
admin.site.register(Estado)