from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^$',homei,name="index"),
    url(r'^crearincidencia/',crearIncidencia, name="crearincidencia"),
    url(r'^listarincidencia/',listarIncidencia, name="listarincidencia"),
    url(r'^editarincidencia/(?P<id>\d+)/$',editarIncidencia,name="editarincidencia"),
    url(r'^eliminarincidencia/(?P<id>\d+)/$',eliminarIncidencia,name="eliminarincidencia"),
    url(r'^mostrarflujo/',mostrarFlujo,name="mostrarflujo"),
]
