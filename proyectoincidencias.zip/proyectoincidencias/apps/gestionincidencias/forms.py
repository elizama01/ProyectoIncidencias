from .models import Incidencia
from django import forms
# Create your views here.
class IncidenciaForm(forms.ModelForm):
    class Meta:
        model = Incidencia
        fields = [
            'nombre_i',
            'estado_i',
            'proyecto_i',
            'detalles_i',
            'responsable_i',
            'evidencia_i',
            'fecha_i',
        ]
        labels={
            'nombre_i':'Ingresar Nombre Incidencia',
            'estado_i':'Estado Incidencia',
            'proyecto_i':'Proyecto',
            'detalles_i':'Detalle de Prueba',
            'responsable_i':'Asignar Responsable',
            'evidencia_i':'Adjuntar Evidencia',
            'fecha_i':'Fecha de Ingreso',
        }

         