from django.apps import AppConfig


class GestionincidenciasConfig(AppConfig):
    name = 'gestionincidencias'
