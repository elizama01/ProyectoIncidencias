from django.apps import AppConfig


class AutentificacionConfig(AppConfig):
    name = 'autentificacion'
