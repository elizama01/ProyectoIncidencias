from django.shortcuts import render, redirect
from django.core.mail import EmailMessage
from .forms import *
from django.http import HttpResponse
from django.contrib.auth.models import User

def contactomail(request):
    try:
        if request.method == 'POST':
            formulario = FormularioContacto(request.POST)
            if formulario.is_valid():
                correo=formulario.cleaned_data['correo']
                ucorreo=User.objects.get(email=correo)
                if (User.objects.get(email=correo)) :
                    asunto='Recuperacion de Contraseña'
                    password=ucorreo.password
                    mail=EmailMessage(asunto,password,to=[correo])
                    mail.send()
                    return redirect('indexc')
                else:
                    return redirect('indexc')    
        else:
            formulario = FormularioContacto()

        return render(request,'autentificacion/index.html',{'formulario':formulario})
    except User.DoesNotExist as e :
        pass