from django.contrib import admin
from apps.gestionproyectos.models import *
# Register your models here.

admin.site.register(Proyecto)
admin.site.register(Estado)

