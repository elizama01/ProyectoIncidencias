from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^$',homep,name="index"),
    url(r'^crearproyecto/',crearProyecto, name="crearproyecto"),
    url(r'^listarproyecto/',listarProyecto, name="listarproyecto"),
    url(r'^editarproyecto/(?P<id>\d+)/$',editarProyecto,name="editarproyecto"),
    url(r'^eliminarproyecto/(?P<id>\d+)/$',eliminarProyecto,name="eliminarproyecto"),
]
