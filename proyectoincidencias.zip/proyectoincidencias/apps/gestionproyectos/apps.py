from django.apps import AppConfig


class GestionproyectosConfig(AppConfig):
    name = 'gestionproyectos'
