from .models import Proyecto
from django import forms
# Create your views here.
class ProyectoForm(forms.ModelForm):
    class Meta:
        model = Proyecto
        fields = [
            'nombre_p',
            'estado_p',
           
        ]
        labels={
            'nombre_p':'Ingresar Nombre Proyecto',
            'estado_p':'Estado de proyecto'
        }