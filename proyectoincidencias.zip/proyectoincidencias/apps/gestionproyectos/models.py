from django.db import models


# Create your models here.
class Estado(models.Model):
    id=models.AutoField(primary_key=True)
    nombre_e = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre_e
    
class Proyecto(models.Model):
    id = models.AutoField(primary_key=True)
    nombre_p = models.CharField(max_length=100)
    estado_p = models.ForeignKey(Estado,on_delete=models.CASCADE)
     
    def __str__(self):
        return self.nombre_p
    