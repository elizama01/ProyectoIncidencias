from django.shortcuts import render, redirect
from .models import *
from .forms import ProyectoForm
from apps.gestionusuarios.models import Usuario
from apps.gestionincidencias.models import Incidencia
from django.contrib.auth.decorators import login_required

@login_required
def homep(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    return render(request,'gestionproyectos/listarproyecto.html',{
        'countu':countu,
        'countp':countp,
        'counti':counti,
         })

@login_required 
def crearProyecto(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    if request.method == 'POST': 
        form = ProyectoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listarproyecto')
    else: 
        form =ProyectoForm()
    return render(request,'gestionproyectos/crearproyecto.html', {'form': form, 'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def listarProyecto(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    proyecto=Proyecto.objects.all()
    context={'proyecto': proyecto,
    'countu':countu,
        'countp':countp,
        'counti':counti,}
    return render(request, 'gestionproyectos/listarproyecto.html',context)

@login_required
def editarProyecto(request,id):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    proyecto=Proyecto.objects.get(id = id)
    if request.method == 'GET':
        form = ProyectoForm(instance = proyecto)
    else:
        form = ProyectoForm(request.POST, instance=proyecto)
        if form.is_valid():
            form.save()
        return redirect('listarproyecto')
    return render(request,'gestionproyectos/crearproyecto.html',{'form':form,'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def eliminarProyecto(request,id):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    proyecto=Proyecto.objects.get(id=id)
    countpi=proyecto.incidencia_set.count()
    if (request.method=='POST'):
       if (countpi==0):
           proyecto.delete()
           return redirect('listarproyecto')
       else:
           return redirect('mensajeeliminar')
    
    return render(request,'gestionproyectos/eliminarproyecto.html', {'proyecto':proyecto,'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def mensajeEliminar(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    return render(request,'gestionproyectos/mensajeeliminar.html', {'countu':countu,
        'countp':countp,
        'counti':counti})

        