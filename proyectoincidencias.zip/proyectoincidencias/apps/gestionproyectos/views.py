from django.shortcuts import render, redirect
from .models import *
from .forms import ProyectoForm

def homep(request):
     return render(request,'gestionproyectos/listarproyecto.html')

def crearProyecto(request):
    if request.method == 'POST': 
        form = ProyectoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listarproyecto')
    else: 
        form =ProyectoForm()
    return render(request,'gestionproyectos/crearproyecto.html', {'form': form})

def listarProyecto(request):
    proyecto=Proyecto.objects.all()
    context={'proyecto': proyecto}
    return render(request, 'gestionproyectos/listarproyecto.html',context)

def editarProyecto(request,id):
    proyecto=Proyecto.objects.get(id = id)
    if request.method == 'GET':
        form = ProyectoForm(instance = proyecto)
    else:
        form = ProyectoForm(request.POST, instance=proyecto)
        if form.is_valid():
            form.save()
        return redirect('listarproyecto')
    return render(request,'gestionproyectos/crearproyecto.html',{'form':form})

def eliminarProyecto(request,id):
    proyecto=Proyecto.objects.get(id=id)
    if (request.method=='POST'):
        proyecto.delete()
        return redirect('listarproyecto')
    return render(request,'gestionproyectos/eliminarproyecto.html', {'proyecto':proyecto})
        