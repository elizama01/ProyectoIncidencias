from django.apps import AppConfig


class GestionusuariosConfig(AppConfig):
    name = 'gestionusuarios'
