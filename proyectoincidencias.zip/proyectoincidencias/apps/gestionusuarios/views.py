from django.shortcuts import render, redirect
from .models import *
from .forms import *
from apps.gestionproyectos.models import Proyecto
from apps.gestionincidencias.models import Incidencia
from django.contrib.auth.decorators import login_required

@login_required
def homeu(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    countasignada=Incidencia.objects.filter(estado_i="1").count()
    countenproceso=Incidencia.objects.filter(estado_i="2").count()
    countfinalizada=Incidencia.objects.filter(estado_i="3").count()
    countvalcliente=Incidencia.objects.filter(estado_i="4").count()
    countcerrada=Incidencia.objects.filter(estado_i="5").count()
    countnoaplica=Incidencia.objects.filter(estado_i="6").count()
    return render(request,'resumen.html',{
        'countu':countu,
        'countp':countp,
        'counti':counti,
        'countasignada':countasignada,
        'countenproceso':countenproceso,
        'countfinalizada':countfinalizada,
        'countvalcliente':countvalcliente,
        'countcerrada':countcerrada,
        'countnoaplica':countnoaplica,
        
        
    })


@login_required
def crearUsuario(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    if request.method == 'POST': 
        form = ExtendedUserCreationForm(request.POST)
        usuario_form=UsuarioForm(request.POST)
        if form.is_valid() and usuario_form.is_valid():
            user=form.save()
            profile= usuario_form.save(commit=False) 
            profile.user=user
            profile.save()
            return redirect('listarusuario')
    else: 
        form =ExtendedUserCreationForm()
        usuario_form=UsuarioForm()
    return render(request,'gestionusuarios/crearusuario.html', {'form': form,'usuario_form':usuario_form,'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def listarUsuario(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    usuario=Usuario.objects.all()
    context={'usuario': usuario,
        'countu':countu,
        'countp':countp,
        'counti':counti}
    return render(request, 'gestionusuarios/listarusuario.html',context)

@login_required
def editarUsuario(request,id):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    usuario=Usuario.objects.get(id = id)
    if request.method == 'GET':
        form = UsuarioForm(instance = usuario)
        formc=ExtendedUserCreationForm(instance=usuario.user)
    else:
        form = UsuarioForm(request.POST, instance=usuario)
        formc= ExtendedUserCreationForm(request.POST,instance=usuario.user)
        if form.is_valid() and formc.is_valid():
            form.save()
            formc.save()
        return redirect('listarusuario')
    return render(request,'gestionusuarios/crearusuario.html',{'usuario_form':form,'form':formc,'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def eliminarUsuario(request,id):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    usuario=Usuario.objects.get(id=id)
    countui=usuario.incidencia_set.count()
    if (request.method=='POST'):
       if (countui==0):
           usuario.user.delete()
           usuario.delete()
           return redirect('listarusuario')
       else:
           return redirect('mensajeeliminar1')
    
    return render(request,'gestionusuarios/eliminarusuario.html', {'usuario':usuario,'countu':countu,
        'countp':countp,
        'counti':counti})

@login_required
def mensajeEliminar(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()

    return render(request,'gestionusuarios/mensajeeliminar.html', {'countu':countu,
        'countp':countp,
        'counti':counti})        