from django.shortcuts import render, redirect
from .models import *
from .forms import UsuarioForm
from apps.gestionproyectos.models import Proyecto
from apps.gestionincidencias.models import Incidencia
def homeu(request):
    countu=Usuario.objects.count()
    countp=Proyecto.objects.count()
    counti=Incidencia.objects.count()
    countasignada=Incidencia.objects.filter(estado_i="1").count()
    countenproceso=Incidencia.objects.filter(estado_i="2").count()
    countfinalizada=Incidencia.objects.filter(estado_i="3").count()
    countvalcliente=Incidencia.objects.filter(estado_i="4").count()
    countcerrada=Incidencia.objects.filter(estado_i="5").count()
    countnoaplica=Incidencia.objects.filter(estado_i="6").count()
    return render(request,'resumen.html',{
        'countu':countu,
        'countp':countp,
        'counti':counti,
        'countasignada':countasignada,
        'countenproceso':countenproceso,
        'countfinalizada':countfinalizada,
        'countvalcliente':countvalcliente,
        'countcerrada':countcerrada,
        'countnoaplica':countnoaplica,
    })

def principal(request):
    return redirect(request,'principal.html')

def crearUsuario(request):
    if request.method == 'POST': 
        form = UsuarioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listarusuario')
    else: 
        form =UsuarioForm()
    return render(request,'gestionusuarios/crearusuario.html', {'form': form})

def listarUsuario(request):
    usuario=Usuario.objects.all()
    context={'usuario': usuario}
    return render(request, 'gestionusuarios/listarusuario.html',context)

def editarUsuario(request,id):
    usuario=Usuario.objects.get(id = id)
    if request.method == 'GET':
        form = UsuarioForm(instance = usuario)
    else:
        form = UsuarioForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
        return redirect('listarusuario')
    return render(request,'gestionusuarios/crearusuario.html',{'form':form})

def eliminarUsuario(request,id):
    usuario=Usuario.objects.get(id=id)
    if (request.method=='POST'):
        usuario.delete()
        return redirect('listarusuario')
    return render(request,'gestionusuarios/eliminarusuario.html', {'usuario':usuario})
        