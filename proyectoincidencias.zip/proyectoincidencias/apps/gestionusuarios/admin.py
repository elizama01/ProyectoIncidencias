from django.contrib import admin
from apps.gestionusuarios.models import *
# Register your models here.

admin.site.register(Usuario)
admin.site.register(Rol)



