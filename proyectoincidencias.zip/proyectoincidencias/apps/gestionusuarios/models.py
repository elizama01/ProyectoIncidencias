from django.db import models
# Create your models here.
class Rol(models.Model):
    id=models.AutoField(primary_key=True)
    nombre_r = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre_r
    
class Usuario(models.Model):
    id = models.AutoField(primary_key=True)
    nombre_u = models.CharField(max_length=100)
    correo_u = models.CharField(max_length=100)
    contrasena_u = models.CharField(max_length=100)
    rol_u = models.ForeignKey(Rol,on_delete=models.CASCADE)
    
    def __str__(self):
        return self.nombre_u
    