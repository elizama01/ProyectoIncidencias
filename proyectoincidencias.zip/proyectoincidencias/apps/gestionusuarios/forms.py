from django import forms
from django.contrib.auth.forms import User
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario
# Create your views here.

class ExtendedUserCreationForm(UserCreationForm):
    email= forms.EmailField( required=True)
    
    class Meta:
        model=User
        fields=['first_name','email','password1']
        labels={
            'first_name':'Nombre',
        }


    def save(self,commit=True):
       
        user= super().save(commit=False)
        user.first_name=self.cleaned_data['first_name']
        user.username=self.cleaned_data['email']
        user.email=self.cleaned_data['email']
        

        if commit:
            user.save()
        return user

class UsuarioForm(forms.ModelForm):
    
    class Meta:
        model = Usuario
        fields = ['rol_u',]