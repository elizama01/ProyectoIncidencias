from .models import Usuario
from django import forms
# Create your views here.
class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = [
            'nombre_u',
            'correo_u',
            'contrasena_u',
            'rol_u',
        ]
        labels={
            'nombre_u':'Ingresar Nombre',
            'correo_u':'Ingresar Correo',
            'contrasena_u':'Ingresar Contraseña',
            'rol_u':'Seleccione Rol'
        }