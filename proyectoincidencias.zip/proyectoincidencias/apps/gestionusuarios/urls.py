from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^$',homeu,name="index"),
    url(r'^principal/',principal,name="principal"),
    url(r'^crearusuario/',crearUsuario, name="crearusuario"),
    url(r'^listarusuario/',listarUsuario, name="listarusuario"),
    url(r'^editarusuario/(?P<id>\d+)/$',editarUsuario,name="editarusuario"),
    url(r'^eliminarusuario/(?P<id>\d+)/$',eliminarUsuario,name="eliminarusuario"),
]
